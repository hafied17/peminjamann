<!DOCTYPE html>
<html>
<head>
	<title>Peminjaman Barang</title>
</head>
<body>

	<?php
	include 'koneksiii.php';
	$no = $_GET['no'];
	$data = mysqli_query($koneksi,"select * from pengambalian where no='$no'");
	while($d = mysqli_fetch_array($data)){
		?>
		<form method="post" action="edit.php">
			<table>
                <tr>
                <td>No Pengembalian</td>
			<td>
				<input type="text" name="no" value="<?php echo $d['no']; ?>">
				
			</td>
                </tr>
				<tr>			
					
					<td>Pemeriksaan</td>
					
					<td><select type="text" name="pem" value="<?php echo $d['pemeriksaan']; ?>">
                      <option >--PILIH--</option>
                      <option value="OKE">OKE</option>
                      <option value="BERMASALAH">BERMASALAH</option>
                    </select></td>
				</tr>
				<tr>
					
					<td></td>
					<td><input type="submit" value="SIMPAN"></td>
				</tr>		
			</table>
		</form>
		<?php 
	}
	?>
 
</body>
</html>