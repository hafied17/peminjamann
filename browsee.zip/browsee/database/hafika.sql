-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 06, 2020 at 08:42 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hafika`
--

-- --------------------------------------------------------

--
-- Table structure for table `akun`
--

CREATE TABLE `akun` (
  `id` int(11) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `NIM` varchar(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `akun`
--

INSERT INTO `akun` (`id`, `nama`, `NIM`, `username`, `password`) VALUES
(1, '', '0', 'hafied1', 'hafied123'),
(8, 'fika', '2147483647', 'fika2', 'fika123'),
(9, 'hafied', '3311801041', 'hafied17', 'hafied123'),
(10, '', '0', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `akunadmin`
--

CREATE TABLE `akunadmin` (
  `no` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `akunadmin`
--

INSERT INTO `akunadmin` (`no`, `username`, `password`) VALUES
(1, 'fika2', 'fika123');

-- --------------------------------------------------------

--
-- Table structure for table `peminjaman`
--

CREATE TABLE `peminjaman` (
  `no` int(11) NOT NULL,
  `nama_kegiatan` varchar(30) NOT NULL,
  `penanggung_jawab` varchar(30) NOT NULL,
  `nama_peminjam` char(20) NOT NULL,
  `NIM` varchar(10) NOT NULL,
  `no_hp` bigint(13) NOT NULL,
  `jenis_barang` varchar(15) NOT NULL,
  `jumlah` int(4) NOT NULL,
  `tanggal_pinjam` date NOT NULL,
  `tanggal_kembali` date NOT NULL,
  `alasan` text NOT NULL,
  `pengajuan` char(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `peminjaman`
--

INSERT INTO `peminjaman` (`no`, `nama_kegiatan`, `penanggung_jawab`, `nama_peminjam`, `NIM`, `no_hp`, `jenis_barang`, `jumlah`, `tanggal_pinjam`, `tanggal_kembali`, `alasan`, `pengajuan`) VALUES
(19, 'osc', 'fika', 'andre', '3311801041', 81277488766, 'Kamera DSLR', 2, '2019-12-01', '2019-12-04', 'kebutuhan lomba', 'Diterima'),
(20, 'osc', 'fika', 'andre', '3311801041', 81277488766, 'Kabel LAN', 2, '2019-12-02', '2019-12-03', 'kebutuhan lomba', 'Diterima'),
(21, 'osc', 'fika', 'andre', '3311801041', 81277488766, 'Kabel LAN', 2, '2019-12-07', '2019-12-08', 'kebutuhan lomba', 'Diterima'),
(22, 'osc', 'fika', 'andre', '3311801041', 81277488766, 'Kabel LAN', 2, '2019-12-28', '2019-12-29', 'kebutuhan lomba', 'Diterima');

-- --------------------------------------------------------

--
-- Table structure for table `pengambalian`
--

CREATE TABLE `pengambalian` (
  `no` int(11) NOT NULL,
  `nama` char(20) NOT NULL,
  `NIM` varchar(10) NOT NULL,
  `no_hp` bigint(13) NOT NULL,
  `jenis_barang` varchar(15) NOT NULL,
  `jumlah` int(5) NOT NULL,
  `tanggal_kembali` date NOT NULL,
  `keterangan` text NOT NULL,
  `gambar` longblob NOT NULL,
  `pemeriksaan` char(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pengambalian`
--

INSERT INTO `pengambalian` (`no`, `nama`, `NIM`, `no_hp`, `jenis_barang`, `jumlah`, `tanggal_kembali`, `keterangan`, `gambar`, `pemeriksaan`) VALUES
(5, 'andre', '3311801087', 81277488766, 'Kamera DSLR', 2, '2019-12-04', '', '', 'OKE'),
(6, 'andre', '3311801087', 81277488766, 'Kamera DSLR', 2, '2019-12-03', 'ok', '', 'OKE'),
(7, 'andre', '3311801087', 81277488766, 'Kamera DSLR', 2, '2019-12-08', 'ok', '', 'OKE'),
(8, 'andre', '3311801087', 81277488766, 'Kamera DSLR', 2, '2019-12-29', 'ok', '', 'OKE');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `akun`
--
ALTER TABLE `akun`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `akunadmin`
--
ALTER TABLE `akunadmin`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `pengambalian`
--
ALTER TABLE `pengambalian`
  ADD PRIMARY KEY (`no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `akun`
--
ALTER TABLE `akun`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `akunadmin`
--
ALTER TABLE `akunadmin`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `peminjaman`
--
ALTER TABLE `peminjaman`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `pengambalian`
--
ALTER TABLE `pengambalian`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
