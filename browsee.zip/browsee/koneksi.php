<?php
   $hostname  = "localhost";
   $username  = "root";
   $password  = "";
   $dbname  = "hafika";
   $db = new PDO('mysql:dbname='.$dbname.';host='.$hostname, $username, $password);
?>