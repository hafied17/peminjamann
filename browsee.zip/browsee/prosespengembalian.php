    <?php
      include "koneksii.php";
      $nk  = $_REQUEST['nama'];
      $pj  = $_REQUEST['NIM'];
      $np  = $_REQUEST['no_hp'];
      $NIM  = $_REQUEST['jenis_barang'];
      $hp  = $_REQUEST['jumlah'];
      $jb  = $_REQUEST['tanggal_kembali'];
      $jml  = $_REQUEST['keterangan'];
      $tp  = $_REQUEST['gambar'];
      $mysqli  = "INSERT INTO pengambalian  VALUES ('','$nk', '$pj', '$np','$NIM','$hp','$jb','$jml','$tp','')";
      $result  = mysqli_query($conn, $mysqli);
      if ($result) {
        echo "<script>alert('Data berhasil di tambahkan!');history.go(-1);</script>";
      } else {
        echo "<script>alert('Gagal di tambahkan!');history.go(-1);</script>";
      }
      mysqli_close($conn);
    ?>