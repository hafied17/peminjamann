<?php 
// koneksi database
include 'koneksiii.php';
 
// menangkap data id yang di kirim dari url
$no = $_GET['no'];
 
 
// menghapus data dari database
mysqli_query($koneksi,"UPDATE peminjaman SET pengajuan ='Diterima' where no='$no'");
 
// mengalihkan halaman kembali ke index.php            
header("location:pengajuann.php");
?>