
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Peminjaman Barang Polibatam</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css?family=Rubik:400,700" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/rangeslider.css">

    <link rel="stylesheet" href="css/style.css">
    
    <style type="text/css">
		body {
			font-family: "Lucida Sans Unicode", "Lucida Grande", "Segoe Ui";
		}
		
		/* Table */
		table {
			margin: auto;
			font-family: "Lucida Sans Unicode", "Lucida Grande", "Segoe Ui";
			font-size: 12px;

		}
		.demo-table {
			border-collapse: collapse;
			font-size: 13px;
		}
		.demo-table th, 
		.demo-table td {
			border-bottom: 1px solid #e1edff;
			border-left: 1px solid #e1edff;
			padding: 7px 17px;
		}
		.demo-table th, 
		.demo-table td:last-child {
			border-right: 1px solid #e1edff;
		}
		.demo-table td:first-child {
			border-top: 1px solid #e1edff;
		}
		.demo-table td:last-child{
			border-bottom: 0;
		}
		caption {
			caption-side: top;
			margin-bottom: 10px;
		}
		
		/* Table Header */
		.demo-table thead th {
			background-color: #00918e;
			color: #FFFFFF;
			border-color: #6ea1cc !important;
			text-transform: uppercase;
		}
		
		/* Table Body */
		.demo-table tbody td {
			color: #353535;
		}
		
		.demo-table tbody tr:nth-child(odd) td {
			background-color: #f4fbff;
		}
		.demo-table tbody tr:hover th,
		.demo-table tbody tr:hover td {
			background-color: #ffffa2;
			border-color: #ffff0f;
			transition: all .2s;
		}
	</style>

  </head>
  <body>
  
  <div class="site-wrap">

    <div class="site-mobile-menu">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
    
    <header class="site-navbar" role="banner">

      <div class="container">
        <div class="row align-items-center">
          
          <div class="col-11 col-xl-2">
            <img src="images/logo.png" alt="" width="180" height="50">
          </div>
          <div class="col-12 col-md-10 d-none d-xl-block">
            <nav class="site-navigation position-relative text-right" role="navigation">

              <ul class="site-menu js-clone-nav mr-auto d-none d-lg-block">
                <li><a href="index.php"><span>Home</span></a></li>
                <li><a href="peminjaman.html "><span>Peminjaman</span></a></li>
                <li><a href="pengembalian.html"><span>Pengembalian</span></a></li>
                <li class="active"><a href="linimasa.php"><span>Pengajuan</span></a></li>
                <li><a href="indexx.html"><span>Logout</span></a></li>
              </ul>
            </nav>
          </div>


          <div class="d-inline-block d-xl-none ml-md-0 mr-auto py-3" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle text-white"><span class="icon-menu h3"></span></a></div>

          </div>

        </div>
      </div>
      
    </header>

  

    <div class="site-blocks-cover inner-page-cover overlay" style="background-image: url(images/hero1.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
      <div class="container">
        <div class="row align-items-center justify-content-center text-center">

          <div class="col-md-10" data-aos="fade-up" data-aos-delay="400">
            
            
            <div class="row justify-content-center">
              <div class="col-md-8 text-center">
                <h1>Pengajuan   </h1>
                <p data-aos="fade-up" data-aos-delay="100">Jadwal dan Persetujuan Barang yang dipinjam.</p>
              </div>
            </div>

            
          </div>
        </div>
      </div>
    </div>  
<br><br>
   
    <table class="demo-table responsive">
      <center><h2>Pengajuan</h2></center>
      
      <form action="linimasaa.php" method="post" class="p-5 bg-white" style="margin-top: -150px;">
      <label class="text-black" >Filter</label> <br>
      <input  name="dari" type="date" name="tanggal">
     -
      <input  name="sampai" type="date" name="tanggal">
      <input type="submit" value="Cari" >
  </form>

      <thead>
		<tr>
			<th scope="col">NO</th>
			<th scope="col">No Pinjam</th>
			<th scope="col">Nama Kegiatan</th>
			<th scope="col">Penanggung Jawab</th>
      <th scope="col">Nama Peminjam</th>
      <th scope="col">NIM</th>
      <th scope="col">No Hp</th>
      <th scope="col">Jenis Barang</th>
      <th scope="col">Jumlah</th>
      <th scope="col">Tanggal Pinjam</th>
      <th scope="col">Tanggal Kembali</th>
      <th scope="col">Alasan</th>
      <th scope="col">Status</th>
      
    </tr>
    </thead>
		<?php 
		include 'koneksiii.php';
		$no = 1;
		$data = mysqli_query($koneksi,"select * from peminjaman");
		while($d = mysqli_fetch_array($data)){
      ?>
      <tbody>
			<tr>
				<td data-header="NO" class="title"><?php echo $no++; ?></td>
				<td data-header="No Pinjam"><?php echo $d['no']; ?></td>
				<td data-header="Nama_kegiatan"><?php echo $d['nama_kegiatan']; ?></td>
        <td data-header="Penanggung_jawab"><?php echo $d['penanggung_jawab']; ?></td>
        <td data-header="nama_peminjam"><?php echo $d['nama_peminjam']; ?></td>
        <td data-header="NIM"><?php echo $d['NIM']; ?></td>
        <td data-header="no_hp"><?php echo $d['no_hp']; ?></td>
        <td data-header="jenis_barang"><?php echo $d['jenis_barang']; ?></td>
        <td data-header="jumlah"><?php echo $d['jumlah']; ?></td>
        <td data-header="tanggal_pinjam"><?php echo $d['tanggal_pinjam']; ?></td>
        <td data-header="tanggal_kembali"><?php echo $d['tanggal_kembali']; ?></td>
        <td data-header="alasan"><?php echo $d['alasan']; ?></td>
        <td data-header="pengajuan"><?php echo $d['pengajuan']; ?></td>
				
      </tr>

      </tbody>
			<?php 
		}
		?>
	</table>

  <br><br>
   
    <table class="demo-table responsive">
      <center><h2>Pengembalian</h2></center>
      <form action="linimasaaa.php" method="post" class="p-5 bg-white" style="margin-top: -150px;">
      <label class="text-black" >Filter</label> <br>
      <input  name="darii" type="date" name="tanggal">
     -
      <input  name="sampaii" type="date" name="tanggal">
      <input type="submit" value="Cari" >
  </form>
      <thead>
		<tr>
      <th scope="col">NO</th>
      <th scope="col">No Pengembalian</th>
			<th scope="col">Nama</th>
			<th scope="col">NIM</th>
			<th scope="col">No Hp</th>
      <th scope="col">Jenis Barang</th>
      <th scope="col">Jumlah</th>
      <th scope="col">Tanggal Kembali</th>
      <th scope="col">Keterangan</th>
      <th scope="col">Gambar</th>
     
    </tr>
    </thead>
		<?php 
		include 'koneksiii.php';
		$no = 1;
		$data = mysqli_query($koneksi,"select * from pengambalian");
		while($d = mysqli_fetch_array($data)){
      ?>
      <tbody>
			<tr>
				<td data-header="NO" class="title"><?php echo $no++; ?></td>
				<td data-header=""><?php echo $d['no']; ?></td>
				<td data-header="Nama_kegiatan"><?php echo $d['nama']; ?></td>
        <td data-header="Penanggung_jawab"><?php echo $d['NIM']; ?></td>
        <td data-header="nama_peminjam"><?php echo $d['no_hp']; ?></td>
        <td data-header="NIM"><?php echo $d['jenis_barang']; ?></td>
        <td data-header="no_hp"><?php echo $d['jumlah']; ?></td>
        <td data-header="jenis_barang"><?php echo $d['tanggal_kembali']; ?></td>
        <td data-header="jumlah"><?php echo $d['keterangan']; ?></td>
        <td data-header="tanggal_pinjam"><?php echo $d['gambar']; ?></td>
       
      </tr>

      </tbody>
			<?php 
		}
		?>
	</table>


    <footer class="site-footer">
        <div class="row pt-2 mt-2">
          <div class="col-12 text-md-center text-left">
            <p> Copyright &copy;<script>document.write(new Date().getFullYear());</script> Hafika
            </p>
          </div>
        </div>
    </footer>
  

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/rangeslider.min.js"></script>
  
  <script src="js/main.js"></script>
  
  </body>
</html>