<?php
   session_start();
   require_once("koneksi.php");
   $username = $_POST['username'];
   $pass = $_POST['password'];
   $query = $db->prepare("SELECT * FROM akunadmin WHERE username = ?");
   $query->execute(array($username));
   $hasil = $query->fetch();
   if($query->rowCount() == 0) {
     echo "<script>alert('Username belum terdaftar!');history.go(-1);</script>";
   } else {
     if($pass <> $hasil['password']) {
       echo "<script>alert('Password Salah!');history.go(-1);</script>";
     } else {
       $_SESSION['username'] = $hasil['username'];
       header('location:pengajuann.php');
     }
   }
?>