<?php 
// koneksi database
include 'koneksiii.php';
 
// menangkap data yang di kirim dari form
$no = $_POST['no'];
$pem = $_POST['pem'];

 
// update data ke database
mysqli_query($koneksi,"update pengambalian set pemeriksaan='$pem' where no='$no'");
 
// mengalihkan halaman kembali ke index.php
header("location:pengajuann.php");
 
?>