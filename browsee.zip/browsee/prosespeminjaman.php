    <?php
      include "koneksii.php";
      $nk  = $_REQUEST['nama_kegiatan'];
      $pj  = $_REQUEST['penanggung_jawab'];
      $np  = $_REQUEST['nama_peminjam'];
      $NIM  = $_REQUEST['NIM'];
      $hp  = $_REQUEST['no_hp'];
      $jb  = $_REQUEST['jenis_barang'];
      $jml  = $_REQUEST['jumlah'];
      $tp  = $_REQUEST['tanggal_pinjam'];
      $tk  = $_REQUEST['tanggal_kembali'];
      $als  = $_REQUEST['alasan'];
      $png  = $_REQUEST['png'];
      $mysqli  = "INSERT INTO peminjaman  VALUES ('','$nk', '$pj', '$np','$NIM','$hp','$jb','$jml','$tp','$tk','$als','$png')";
      $result  = mysqli_query($conn, $mysqli);
      if ($result) {
        echo "<script>alert('Data berhasil di tambahkan!');history.go(-1);</script>";
      } else {
        echo "<script>alert('Gagal di tambahkan!');history.go(-1);</script>";
      }
      mysqli_close($conn);
    ?>