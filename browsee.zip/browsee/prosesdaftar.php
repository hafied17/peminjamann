    <?php
      include "koneksii.php";
      $nm  = $_REQUEST['nama'];
      $NIM  = $_REQUEST['NIM'];
      $un  = $_REQUEST['username'];
      $pssd = $_REQUEST['password'];
      $pssdd  = $_REQUEST['passwordd'];
      if($pssd == $pssdd){
      $mysqli  = "INSERT INTO akun  VALUES ('','$nm', '$NIM', '$un','$pssd')";
      $result  = mysqli_query($conn, $mysqli);
      
       
        if ($result) {
          echo "<script>alert('Data berhasil di tambahkan!');history.go(-1);</script>";
        } else {
          echo "<script>alert('Gagal di tambahkan!');history.go(-1);</script>";
        }
        header('location:login.php');
      }
      else{
        echo "<script>alert('Password tidak sama!');history.go(-1);</script>";
      }
      mysqli_close($conn);
    ?>